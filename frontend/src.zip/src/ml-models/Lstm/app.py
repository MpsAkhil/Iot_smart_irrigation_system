from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
import requests
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.keras.utils import CustomObjectScope
import joblib
from datetime import datetime, timedelta
import logging

app = Flask(__name__)
CORS(app)

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load the weather forecast model and scaler
with CustomObjectScope({'mse': MeanSquaredError()}):
    weather_model = load_model('weather_forecast_model.h5')
weather_scaler = joblib.load('scaler.pkl')

# Load the motor on-time prediction model and scaler
# Use joblib.load if the model is a scikit-learn model or saved using joblib
motor_model = joblib.load('next_watering_model.pkl')  # Replace with your motor model
motor_scaler = joblib.load('scaler1.pkl')  # Replace with your motor scaler

# Open-Meteo API URL
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

def get_lat_lon_from_city(city_name):
    """
    Fetches latitude and longitude for a city using Open-Meteo's Geocoding API.
    Returns a tuple of (latitude, longitude) as floats.
    """
    base_url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {
        "name": city_name,
        "count": 1,  # Limit to 1 result
        "format": "json",
    }
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()
        if data.get("results"):
            # Return the latitude and longitude of the first result
            return float(data["results"][0]["latitude"]), float(data["results"][0]["longitude"])
        else:
            logger.error(f"No results found for city: {city_name}")
            return None, None
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch data from Open-Meteo Geocoding API: {e}")
        return None, None

def fetch_open_meteo_data(latitude, longitude, start_date, end_date):
    """
    Fetches historical weather data from the Open-Meteo API.
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "temperature_2m,relativehumidity_2m,pressure_msl,cloudcover,windspeed_10m",
        "start_date": start_date.strftime('%Y-%m-%d'),
        "end_date": end_date.strftime('%Y-%m-%d'),
    }
    
    try:
        response = requests.get(OPEN_METEO_URL, params=params)
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()
        
        weather_data = []
        for i in range(len(data['hourly']['time'])):
            weather_data.append([
                data['hourly']['time'][i],
                data['hourly']['temperature_2m'][i],
                data['hourly']['relativehumidity_2m'][i],
                data['hourly']['pressure_msl'][i],
                data['hourly']['cloudcover'][i],
                1 if data['hourly']['cloudcover'][i] < 20 else 0,  # Simplified weather code
                data['hourly']['windspeed_10m'][i],
            ])
        
        df = pd.DataFrame(weather_data, columns=[
            'datetime', 'temperature', 'humidity', 'pressure', 'cloud_cover', 'weather_code', 'wind_speed'
        ])
        return df
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch data from Open-Meteo API: {e}")
        logger.error(f"API Response: {response.text if 'response' in locals() else 'No response'}")
        return None

def preprocess_new_city_data(new_city_data):
    """
    Preprocesses the new city data using the saved scaler.
    """
    weather_data = new_city_data.drop(columns=['datetime'])
    scaled_data = weather_scaler.transform(weather_data)
    return scaled_data

def predict_new_city_weather(new_city_data):
    """
    Predicts the next 6 hours of weather data.
    """
    new_city_data_normalized = preprocess_new_city_data(new_city_data)
    last_sequence = new_city_data_normalized[-24:]
    last_sequence = np.expand_dims(last_sequence, axis=0)
    predictions = weather_model.predict(last_sequence)
    predictions = predictions.reshape(-1, predictions.shape[2])
    predictions = weather_scaler.inverse_transform(predictions)
    return predictions

@app.route('/predict', methods=['POST'])
def predict():
    """
    API endpoint to predict weather for a new city.
    """
    try:
        data = request.json
        if 'city_name' not in data:
            return jsonify({"error": "Missing 'city_name' in request body"}), 400

        city_name = data['city_name']
        now = datetime.now()
        end_time = now
        start_time = now - timedelta(hours=24)

        # Get latitude and longitude for the city
        latitude, longitude = get_lat_lon_from_city(city_name)
        if latitude is None or longitude is None:
            return jsonify({"error": "Failed to fetch location data for the city"}), 500

        logger.debug(f"Fetching data for latitude={latitude}, longitude={longitude}, start_time={start_time}, end_time={end_time}")
        new_city_data = fetch_open_meteo_data(latitude, longitude, start_time, end_time)
        if new_city_data is None:
            return jsonify({"error": "Failed to fetch data from Open-Meteo API"}), 500

        new_city_data['datetime'] = pd.to_datetime(new_city_data['datetime'])
        processed_new_city_data = new_city_data[(new_city_data['datetime'] >= (now - timedelta(hours=24))) & (new_city_data['datetime'] <= now)]
        processed_new_city_data = processed_new_city_data.tail(24)

        if len(processed_new_city_data) < 24:
            return jsonify({"error": "Insufficient data for prediction"}), 400

        predictions = predict_new_city_weather(processed_new_city_data)
        prediction_columns = ['temperature', 'humidity', 'pressure', 'cloud_cover', 'weather_code', 'wind_speed']
        predictions_df = pd.DataFrame(predictions, columns=prediction_columns)

        return jsonify(predictions_df.to_dict(orient='records'))
    except Exception as e:
        logger.error(f"Error in /predict endpoint: {e}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500

@app.route('/predict-motor', methods=['POST'])
def predict_motor():
    """
    API endpoint to predict motor on-time based on user inputs.
    """
    try:
        data = request.json
        if not all(key in data for key in ['temperature', 'humidity', 'soil_moisture', 'water_level']):
            return jsonify({"error": "Missing required fields: temperature, humidity, soil_moisture, water_level"}), 400

        # Prepare input data for the motor model
        input_data = np.array([
            data['temperature'],
            data['humidity'],
            data['soil_moisture'],
            data['water_level'],
        ]).reshape(1, -1)

        # Scale the input data
        input_data_scaled = motor_scaler.transform(input_data)

        # Predict motor on-time
        motor_on_time = motor_model.predict(input_data_scaled)[0]

        return jsonify({"motor_on_time": float(motor_on_time)})
    except Exception as e:
        logger.error(f"Error in /predict-motor endpoint: {e}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500
# Load the second motor on-time prediction model and scaler
motor_model_2 = joblib.load('motor_model.pkl')  # Replace with your second motor model
motor_scaler_2 = joblib.load('scaler2.pkl')  # Replace with your second motor scaler

@app.route('/predict-motor-2', methods=['POST'])
def predict_motor_2():
    """
    API endpoint to predict motor on-time based on user inputs for the second model.
    """
    try:
        data = request.json
        if not all(key in data for key in ['temperature', 'humidity', 'soil_moisture', 'water_level']):
            return jsonify({"error": "Missing required fields: temperature, humidity, soil_moisture, water_level"}), 400

        # Prepare input data for the motor model
        input_data = np.array([
            data['temperature'],
            data['humidity'],
            data['soil_moisture'],
            data['water_level'],
        ]).reshape(1, -1)

        # Scale the input data
        input_data_scaled = motor_scaler_2.transform(input_data)

        # Predict motor on-time
        motor_on_time = motor_model_2.predict(input_data_scaled)[0]

        return jsonify({"motor_on_time": float(motor_on_time)})
    except Exception as e:
        logger.error(f"Error in /predict-motor-2 endpoint: {e}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    app.run(debug=True)