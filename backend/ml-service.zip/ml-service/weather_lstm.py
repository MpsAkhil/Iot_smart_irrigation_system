from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np
import pandas as pd
import requests
from datetime import datetime, timedelta
from tensorflow.keras.models import load_model
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.keras.utils import CustomObjectScope
import logging
import tensorflow as tf

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Open-Meteo API URL
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

# Load the models and scalers
try:
    # Enable eager execution
    tf.config.run_functions_eagerly(True)
    
    # Load weather forecast model and scaler with custom objects
    custom_objects = {
        'MeanSquaredError': MeanSquaredError,
        'mse': MeanSquaredError,
        'InputLayer': tf.keras.layers.InputLayer
    }
    
    # Create a new model with the same architecture
    input_shape = (24, 6)  # Based on the batch_shape from the error
    inputs = tf.keras.Input(shape=input_shape)
    x = inputs
    
    # Add LSTM layers with correct output shapes
    x = tf.keras.layers.LSTM(50, return_sequences=True)(x)
    x = tf.keras.layers.LSTM(50)(x)
    x = tf.keras.layers.Dense(36)(x)  # Changed from 6 to 36 to match saved weights
    x = tf.keras.layers.Reshape((6, 6))(x)  # Reshape to match the expected output shape
    
    forecast_model = tf.keras.Model(inputs=inputs, outputs=x)
    
    # Load the weights
    forecast_model.load_weights('weather_forecast_model.h5')
    
    # Load scaler with error handling
    try:
        forecast_scaler = joblib.load('scaler.pkl')
    except Exception as scaler_error:
        logger.error(f"Error loading scaler: {scaler_error}")
        # Create a new scaler if loading fails
        from sklearn.preprocessing import MinMaxScaler
        forecast_scaler = MinMaxScaler()
    
    logger.info("Successfully loaded weather model and scaler")
except Exception as e:
    logger.error(f"Error loading weather model or scaler: {e}")
    raise

def get_lat_lon_from_city(city_name):
    """
    Fetches latitude and longitude for a city using Open-Meteo's Geocoding API.
    Returns a tuple of (latitude, longitude) as floats.
    """
    base_url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {
        "name": city_name,
        "count": 1,  # Limit to 1 result
        "format": "json",
    }
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()
        if data.get("results"):
            # Return the latitude and longitude of the first result
            return float(data["results"][0]["latitude"]), float(data["results"][0]["longitude"])
        else:
            print(f"No results found for city: {city_name}")
            return None, None
    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch data from Open-Meteo Geocoding API: {e}")
        return None, None
    
def fetch_open_meteo_data(latitude, longitude, start_date, end_date):
    """
    Fetches historical weather data from the Open-Meteo API.
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "temperature_2m,relativehumidity_2m,pressure_msl,cloudcover,windspeed_10m",
        "start_date": start_date.strftime('%Y-%m-%d'),
        "end_date": end_date.strftime('%Y-%m-%d'),
    }
    
    try:
        response = requests.get(OPEN_METEO_URL, params=params)
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()
        
        weather_data = []
        for i in range(len(data['hourly']['time'])):
            weather_data.append([
                data['hourly']['time'][i],
                data['hourly']['temperature_2m'][i],
                data['hourly']['relativehumidity_2m'][i],
                data['hourly']['pressure_msl'][i],
                data['hourly']['cloudcover'][i],
                1 if data['hourly']['cloudcover'][i] < 20 else 0,  # Simplified weather code
                data['hourly']['windspeed_10m'][i],
            ])
        
        df = pd.DataFrame(weather_data, columns=[
            'datetime', 'temperature', 'humidity', 'pressure', 'cloud_cover', 'weather_code', 'wind_speed'
        ])
        return df
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch data from Open-Meteo API: {e}")
        logger.error(f"API Response: {response.text if 'response' in locals() else 'No response'}")
        return None

def preprocess_new_city_data(new_city_data):
    """
    Preprocesses the new city data using the saved scaler.
    """
    try:
        weather_data = new_city_data.drop(columns=['datetime'])
        # Fit the scaler if it's not fitted
        if not hasattr(forecast_scaler, 'n_features_in_'):
            forecast_scaler.fit(weather_data)
        scaled_data = forecast_scaler.transform(weather_data)
        return scaled_data
    except Exception as e:
        logger.error(f"Error in preprocessing: {e}")
        # Fallback to manual scaling if scaler fails
        weather_data = new_city_data.drop(columns=['datetime'])
        min_vals = weather_data.min()
        max_vals = weather_data.max()
        scaled_data = (weather_data - min_vals) / (max_vals - min_vals)
        return scaled_data.values

def predict_new_city_weather(new_city_data):
    """
    Predicts the next 6 hours of weather data.
    """
    try:
        new_city_data_normalized = preprocess_new_city_data(new_city_data)
        last_sequence = new_city_data_normalized[-24:]
        last_sequence = np.expand_dims(last_sequence, axis=0)
        
        # Ensure the input shape matches the model's expected shape
        if len(last_sequence.shape) == 2:
            last_sequence = np.expand_dims(last_sequence, axis=1)
        
        predictions = forecast_model.predict(last_sequence)
        predictions = predictions.reshape(-1, predictions.shape[2])
        
        # Inverse transform predictions
        try:
            # Ensure predictions are 2D before inverse transform
            if len(predictions.shape) == 1:
                predictions = predictions.reshape(1, -1)
            predictions = forecast_scaler.inverse_transform(predictions)
        except Exception as e:
            logger.error(f"Error in inverse transform: {e}")
            # Fallback to manual inverse scaling if scaler fails
            min_vals = new_city_data.drop(columns=['datetime']).min()
            max_vals = new_city_data.drop(columns=['datetime']).max()
            predictions = predictions.reshape(-1, len(min_vals))
            predictions = predictions * (max_vals - min_vals) + min_vals
        
        return predictions
    except Exception as e:
        logger.error(f"Error in prediction: {e}")
        raise

@app.route('/predict', methods=['POST'])
def predict_weather():
    """
    API endpoint to predict weather for a new city.
    """
    try:
        data = request.json
        if 'city_name' not in data:
            return jsonify({"error": "Missing 'city_name' in request body"}), 400

        city_name = data['city_name']
        now = datetime.now()
        end_time = now
        start_time = now - timedelta(hours=24)

        # Get latitude and longitude for the city
        latitude, longitude = get_lat_lon_from_city(city_name)
        if latitude is None or longitude is None:
            return jsonify({"error": "Failed to fetch location data for the city"}), 500

        logger.debug(f"Fetching data for latitude={latitude}, longitude={longitude}, start_time={start_time}, end_time={end_time}")
        new_city_data = fetch_open_meteo_data(latitude, longitude, start_time, end_time)
        if new_city_data is None:
            return jsonify({"error": "Failed to fetch data from Open-Meteo API"}), 500

        new_city_data['datetime'] = pd.to_datetime(new_city_data['datetime'])
        processed_new_city_data = new_city_data[(new_city_data['datetime'] >= (now - timedelta(hours=24))) & (new_city_data['datetime'] <= now)]
        processed_new_city_data = processed_new_city_data.tail(24)

        if len(processed_new_city_data) < 24:
            return jsonify({"error": "Insufficient data for prediction"}), 400

        predictions = predict_new_city_weather(processed_new_city_data)
        prediction_columns = ['temperature', 'humidity', 'pressure', 'cloud_cover', 'weather_code', 'wind_speed']
        predictions_df = pd.DataFrame(predictions, columns=prediction_columns)

        return jsonify(predictions_df.to_dict(orient='records'))
    except Exception as e:
        logger.error(f"Error in /predict endpoint: {e}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(port=5002, debug=True) 