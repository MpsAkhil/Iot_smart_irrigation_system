import requests
import json

def test_endpoints():
    base_url = "http://localhost:5001"
    
    # Test predict-motor endpoint
    print("\nTesting /predict-motor endpoint:")
    data = {
        "temperature": 25,
        "humidity": 60,
        "soil_moisture": 40,
        "water_level": 80
    }
    try:
        response = requests.post(f"{base_url}/predict-motor", json=data)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"Error: {e}")

    # Test predict-motor-2 endpoint
    print("\nTesting /predict-motor-2 endpoint:")
    try:
        response = requests.post(f"{base_url}/predict-motor-2", json=data)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"Error: {e}")

    # Test predict endpoint
    print("\nTesting /predict endpoint:")
    data = {"city_name": "London"}
    try:
        response = requests.post(f"{base_url}/predict", json=data)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_endpoints() 